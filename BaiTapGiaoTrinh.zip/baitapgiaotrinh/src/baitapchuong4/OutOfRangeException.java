package baitapchuong4;

public class OutOfRangeException extends Exception {

	public OutOfRangeException(String mesages) {
		super(mesages);
	}
	

}

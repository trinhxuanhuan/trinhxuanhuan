package baitapchuong4;

public class StringTooLongException extends Exception{

	public StringTooLongException(String mesages) {
		super(mesages);
	}
	

}

package baitapchuong4;

public class InvalidDateException extends Exception{
	public InvalidDateException(String mesages) {
		super(mesages);
	}

}

package baitapchuong2;

public class Bai8 {
	public static void main(String[] args) {
		int sum = 0;
		int n = 100;
		for(int i = 2; i <= n; i += 2) {
			sum += i;
			
		}
		System.out.println("Tong cua 100 so nguyen chan dau tien la: " + sum);
	}

}

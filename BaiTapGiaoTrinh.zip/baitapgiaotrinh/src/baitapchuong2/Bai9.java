package baitapchuong2;

public class Bai9 {
	public static void main(String[] args) {
		int sum = 0;
		int n = 99;
		for(int i = 1; i <= n; i+=2) {
			sum += i;
		}
		System.out.println("Tong 100 cac so le dau tien la: " + sum);
	}

}
